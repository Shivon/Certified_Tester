/**
 * 
 */
/**
 * 
 * The logic package handles all data related calculations and storage tasks
 * @author goat
 * @version 1.0
 */
package logic;



